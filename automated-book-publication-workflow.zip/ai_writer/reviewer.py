def review_chapter(content):
    return f"Reviewed Content:\n\n{content}\n\n[Reviewed by AI Reviewer]"

if __name__ == "__main__":
    with open("chapter1_spun.txt", "r", encoding="utf-8") as f:
        spun = f.read()
    reviewed = review_chapter(spun)
    with open("chapter1_final.txt", "w", encoding="utf-8") as f:
        f.write(reviewed)