def rewrite_chapter(content):
    return f"AI-Spun Version:\n\n{content}\n\n[Modified by AI Writer]"

if __name__ == "__main__":
    with open("chapter1.txt", "r", encoding="utf-8") as f:
        original = f.read()
    spun = rewrite_chapter(original)
    with open("chapter1_spun.txt", "w", encoding="utf-8") as f:
        f.write(spun)