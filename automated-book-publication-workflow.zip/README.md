# 📚 Automated Book Publication Workflow

## 🚀 Project Overview
A system to scrape book content from online sources, rewrite chapters using AI, enable human-in-the-loop editing, and version control using ChromaDB with intelligent search retrieval.

## 🛠 Features
- ✅ Web scraping of book content (Playwright)
- ✅ Screenshot capture of web pages
- ✅ AI-generated rewrites of chapters using LLM
- ✅ Human-in-the-loop interface for reviewing/editing
- ✅ Versioning with ChromaDB
- ✅ RL-based search (placeholder)

## 💻 How to Run
1. Clone the Repository
2. Install Dependencies: `pip install -r requirements.txt`
3. Run the Scraper: `python scraping/scrape_and_screenshot.py`
4. Run AI Writer & Reviewer: `python ai_writer/writer.py && python ai_writer/reviewer.py`
5. Store Final Versions: `python versioning/chromadb_store.py`

## 📺 Demo Video
[Add your demo video link here]

## 📜 License
Evaluation purpose only. Developer retains full license.