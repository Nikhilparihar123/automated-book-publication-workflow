import chromadb
from chromadb.utils import embedding_functions

client = chromadb.Client()
collection = client.create_collection("chapters")

def store_version(content, chapter_id="chapter1"):
    collection.add(documents=[content], ids=[chapter_id])

if __name__ == "__main__":
    with open("chapter1_final.txt", "r", encoding="utf-8") as f:
        final_version = f.read()
    store_version(final_version)